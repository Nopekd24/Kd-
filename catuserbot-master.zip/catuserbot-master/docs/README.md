---
description: >-
  A powerful and versatile userbot designed to make you more lazy by doing
  everything from telegram itself.
---

# Introduction

<figure><img src=".gitbook/assets/catlogo.jpg" alt="Cat Logo" width="280"><figcaption><p>Vidushano</p></figcaption></figure>

Catuserbot has been developed using Python programming language and Telethon MTProto, a client library for the Telegram API that provides a secure and reliable way to interact with the Telegram platform.
