# 📕 G-Drive

open this [https://da.gd/so63O ](https://da.gd/so63O)and login with your gmail(the drive which you are going to link)**This plugin also requires the PRIVATE\_GROUP\_BOT\_API\_ID to be set. if it was not setted then refer this message**

[https://t.me/catuserbot17/12](https://t.me/catuserbot17/12)

Now select create project , accept the Terms of Service, and select your Country.

Then click on agree and continue

<figure><img src="https://telegra.ph/file/0af7f3bf0051069eba904.png" alt=""><figcaption></figcaption></figure>

Now Click on Get Credentials button.

<figure><img src="https://telegra.ph/file/20ae8cfaf80cf1f2074dd.png" alt=""><figcaption></figcaption></figure>

Then In the new screen, You need to follow these

Which API are you using?select Google Drive API from the drop down.

For Where will you be calling the API from? select Other UI (e.g. Windows, CLI tool)

For What data will you be accessing? select User data.

Click on What credentials do I need?

<figure><img src="https://telegra.ph/file/7f0751905b3ae4896b9ae.png" alt=""><figcaption></figcaption></figure>

Now a pop up appears as below click on SET UP CONSENT SCREEN in that pop up

<figure><img src="https://telegra.ph/file/3315f9ac2a92bd3a137b1.png" alt=""><figcaption></figcaption></figure>

Now click on external and click on create

<figure><img src="https://telegra.ph/file/4dda1ed494c9e3ccbc539.png" alt=""><figcaption></figcaption></figure>

Now in the New tab Enter the application name, support email & confim email.. and scroll to bottom and click on save

<figure><img src="https://telegra.ph/file/53b40d8b3eba820163f19.png" alt=""><figcaption></figcaption></figure>

<figure><img src="https://telegra.ph/file/17a4352bb5235e575e9b8.png" alt=""><figcaption></figcaption></figure>

Then save & confim all four page & publish you app.

<figure><img src="https://telegra.ph/file/2e9aede96706c120b74a8.png" alt=""><figcaption></figcaption></figure>

Then push the production ...**Click Confirm.**

<figure><img src="https://telegra.ph/file/32d0fa13f335acbdfac9e.png" alt=""><figcaption></figcaption></figure>

Close these tab and go to previous tab . and refresh it and

click on Create OAuth client id

<figure><img src="https://telegra.ph/file/1cfc44f3a8fe4bff8e6f8.png" alt=""><figcaption></figcaption></figure>

then click on Done button

<figure><img src="https://telegra.ph/file/3150445588c633df60c49.png" alt=""><figcaption></figcaption></figure>

now click on create credentials

<figure><img src="https://telegra.ph/file/425a9cfa4ccf3dbdc51d8.png" alt=""><figcaption></figcaption></figure>

and then on OAuth client ID

<figure><img src="https://telegra.ph/file/30ee89d963c82eecd6bd6.png" alt=""><figcaption></figcaption></figure>

here in the new tab in the application drop down click on desktop app

<figure><img src="https://telegra.ph/file/5f6f7ee4d47875c1fa719.png" alt=""><figcaption></figcaption></figure>

#### Do Any one process from the bellow two types : <a href="#do-any-one-process-from-the-bellow-two-types" id="do-any-one-process-from-the-bellow-two-types"></a>

#### Type 1 :- <a href="#type-1" id="type-1"></a>

**and then finally on create button then go back and click on the following download symbol as shown in the following image beside that pencil and dustbin.**

<figure><img src="https://telegra.ph/file/737d25b012bb5f72d60a7.png" alt=""><figcaption></figcaption></figure>

Now set **G\_DRIVE\_DATA** this var with the content of the file you downloaded\
i.e , open that downloaded file and copy the whole thing in that file and paste in the value

\


#### Type 2 :- <a href="#type-2" id="type-2"></a>

click on the client name & open it.

<figure><img src="https://telegra.ph/file/58e750a52425b6969bc2c.png" alt=""><figcaption></figcaption></figure>

then u will find your **Client id** & **Client Secret**

<figure><img src="https://telegra.ph/file/7e043ed8d540f7f312d3f.png" alt=""><figcaption></figcaption></figure>

Now set **G\_DRIVE\_CLIENT\_ID** & **G\_DRIVE\_CLIENT\_SECRET** var with the values

\


\


\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*For the users who have down before gdrive now follow this step open the site below in desktop mode

[https://da.gd/zNuETm](https://da.gd/zNuETm)

<figure><img src="https://telegra.ph/file/cf9430655481af3c1e402.png" alt=""><figcaption></figcaption></figure>

now click on the credentials and follow last but one step in the above process whih i made bold text

***

Finally type .gauth in telegram to configure

and set the G\_DRIVE\_FOLDER\_ID with respective folder url to upload to those folder
