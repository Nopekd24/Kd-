---
description: >-
  Github commit is use to upload plugins to ur github repo, so they didn't get
  unload after restart
---

# 📕 Github Commit

To set-up click [Here](https://github.com/settings/tokens) & login with Github in which u forked the repo.

\
Now Click on "Personal Access Token" & "Generate"

<figure><img src="https://te.legra.ph/file/95dfd5aca517cd8c4ed75.jpg" alt=""><figcaption></figcaption></figure>

Will get this page set note Anything u want & tick "repo" & "read" like in picture. Then click on "Generate token"

<figure><img src="https://te.legra.ph/file/e2cb090124db2e7036414.jpg" alt=""><figcaption></figcaption></figure>

&#x20;You will get your Token copy that somewhere. Then go to github home page

<figure><img src="https://te.legra.ph/file/90758900916d1d9587199.jpg" alt=""><figcaption></figcaption></figure>

These are github repo names.

\
Now go to heroku & set these vers & values

<figure><img src="https://te.legra.ph/file/07e1143dccb8592b3a915.jpg" alt=""><figcaption></figcaption></figure>

Vars :- GITHUB\_ACCESS\_TOKEN & GIT\_REPO\_NAME

Value :- The token you copied & repo name
