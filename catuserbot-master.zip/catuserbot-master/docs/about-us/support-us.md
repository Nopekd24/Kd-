---
description: >-
  Thank you for your interest in supporting TgCatUB! Your contribution helps us
  maintain our open-source repositories.
---

# 🖤 Support Us

## ≡  How to Donate

_We accept donations through UPI, PayPal, and Bitcoin._

* **UPI :** You can donate using our UPI ID  -->   <mark style="color:purple;">**md.jisan@ybl**</mark>&#x20;
* **PayPal :** You can donate using our PayPal  --> &#x20;
* **Bitcoin :** You can donate Bitcoin to our wallet address  -->  <mark style="color:purple;">**bc1qd6pgnstm0cm366ztxqmd45src250lz0cgm40ch**</mark>

Your support is greatly appreciated and will help us continue our mission of fostering collaboration and innovation in the tech industry. Thank you for helping us make a difference!
